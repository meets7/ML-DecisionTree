Machine learning
Assignment 1
Name: Dhruv Sangvikar
netid: dgs160230
-------------------------------------------------------------------
									Instructions
-------------------------------------------------------------------

Code is python based.

1. place the data file folders at the level of the all the code files.
2. Run the program using the following command :

python runId3.py 10 18 data_sets2/training_set.csv data_sets2/validation_set.csv data_sets2/test_set.csv no

3. I would recommend printing the tree to an output.txt file or similar, and view it from there. 

You can copy paste the following command for that:

python runId3.py 25 8 data_sets2/training_set.csv data_sets2/validation_set.csv data_sets2/test_set.csv yes > output.txt

Thanks.

--------------------------------------------------------------------
--------------------------------------------------------------------



